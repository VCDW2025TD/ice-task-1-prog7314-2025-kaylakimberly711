﻿using System;
using System.Collections.Generic;
using System.Linq;
using PlaylistApp.DataStructures;
using PlaylistApp.Models;

namespace PlaylistApp.Services
{
    public class PlaylistManager
    {
        private readonly DoublyLinkedList<Track> _list = new();
        public DoublyLinkedListNode<Track>? Current { get; private set; }
        public IEnumerable<Track> Tracks => _list.AsEnumerable();
        public Track? CurrentTrack => Current?.Value;

        public void Add(Track track)
        {
            var node = _list.AddLast(track);
            if (Current == null) Current = node; // first track becomes current
        }

        public void AddAfterCurrent(Track track)
        {
            if (Current == null) { Add(track); return; }
            _list.AddAfter(Current, track);
        }

        public void RemoveCurrent()
        {
            if (Current == null) return;
            var next = Current.Next ?? Current.Prev;
            _list.Remove(Current);
            Current = next;
        }

        public void Next() { if (Current?.Next != null) Current = Current.Next; }
        public void Prev() { if (Current?.Prev != null) Current = Current.Prev; }

        public void Shuffle()
        {
            var items = _list.AsEnumerable().ToList();
            var rng = new Random();
            for (int i = items.Count - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (items[i], items[j]) = (items[j], items[i]);
            }

            var keep = Current?.Value;
            // rebuild list
            var newList = new DoublyLinkedList<Track>();
            foreach (var t in items) newList.AddLast(t);
            // swap lists
            typeof(PlaylistManager).GetField("_list",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!
                .SetValue(this, newList);

            // restore Current
            Current = null;
            var n = newList.Head;
            while (n != null)
            {
                if (ReferenceEquals(n.Value, keep)) { Current = n; break; }
                n = n.Next;
            }
            if (Current == null) Current = newList.Head;
        }

        public void SetCurrentByIndex(int index)
        {
            int i = 0; var n = _list.Head;
            while (n != null)
            {
                if (i == index) { Current = n; return; }
                i++; n = n.Next;
            }
        }
    }
}
