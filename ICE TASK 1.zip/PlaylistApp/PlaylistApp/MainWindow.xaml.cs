﻿using System.Collections.ObjectModel;
using System.Windows;
using PlaylistApp.Models;
using PlaylistApp.Services;

namespace PlaylistApp
{
    public partial class MainWindow : Window
    {
        private readonly PlaylistManager _playlist = new();
        private readonly ObservableCollection<Track> _uiTracks = new();

        public MainWindow()
        {
            InitializeComponent();
            TrackList.ItemsSource = _uiTracks;

            // Seed demo tracks
            _playlist.Add(new Track { Title = "Intro", Artist = "The Course" });
            _playlist.Add(new Track { Title = "Pointers", Artist = "C# Band" });
            _playlist.Add(new Track { Title = "Generics", Artist = "Templates" });

            RefreshUI();
        }

        private void RefreshUI()
        {
            _uiTracks.Clear();
            foreach (var t in _playlist.Tracks) _uiTracks.Add(t);

            CurrentRun.Text = _playlist.CurrentTrack?.ToString() ?? "(none)";
            var idx = _playlist.CurrentTrack != null ? _uiTracks.IndexOf(_playlist.CurrentTrack) : -1;
            TrackList.SelectedIndex = idx;
            if (idx >= 0) TrackList.ScrollIntoView(TrackList.SelectedItem);
        }

        private void AddAfter_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleBox.Text) || string.IsNullOrWhiteSpace(ArtistBox.Text))
            {
                MessageBox.Show("Please enter both Title and Artist.");
                return;
            }
            _playlist.AddAfterCurrent(new Track { Title = TitleBox.Text.Trim(), Artist = ArtistBox.Text.Trim() });
            TitleBox.Clear(); ArtistBox.Clear();
            RefreshUI();
        }

        private void AddEnd_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleBox.Text) || string.IsNullOrWhiteSpace(ArtistBox.Text))
            {
                MessageBox.Show("Please enter both Title and Artist.");
                return;
            }
            _playlist.Add(new Track { Title = TitleBox.Text.Trim(), Artist = ArtistBox.Text.Trim() });
            TitleBox.Clear(); ArtistBox.Clear();
            RefreshUI();
        }

        private void Remove_Click(object sender, RoutedEventArgs e) { _playlist.RemoveCurrent(); RefreshUI(); }
        private void Next_Click(object sender, RoutedEventArgs e) { _playlist.Next(); RefreshUI(); }
        private void Prev_Click(object sender, RoutedEventArgs e) { _playlist.Prev(); RefreshUI(); }

        private void Shuffle_Click(object sender, RoutedEventArgs e) { _playlist.Shuffle(); RefreshUI(); }

        private void TrackList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            var idx = TrackList.SelectedIndex;
            if (idx >= 0) { _playlist.SetCurrentByIndex(idx); CurrentRun.Text = _playlist.CurrentTrack?.ToString() ?? "(none)"; }
        }
    }
}
