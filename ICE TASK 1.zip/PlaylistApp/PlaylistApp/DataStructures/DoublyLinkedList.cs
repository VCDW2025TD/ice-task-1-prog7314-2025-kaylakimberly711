﻿using System;
using System.Collections.Generic;

namespace PlaylistApp.DataStructures
{
    public class DoublyLinkedListNode<T>
    {
        public T Value { get; set; }
        public DoublyLinkedListNode<T>? Prev { get; internal set; }
        public DoublyLinkedListNode<T>? Next { get; internal set; }

        public DoublyLinkedListNode(T value) => Value = value;
    }

    public class DoublyLinkedList<T>
    {
        public DoublyLinkedListNode<T>? Head { get; private set; }
        public DoublyLinkedListNode<T>? Tail { get; private set; }
        public int Count { get; private set; }

        public DoublyLinkedListNode<T> AddLast(T value)
        {
            var node = new DoublyLinkedListNode<T>(value);
            if (Head == null)
            {
                Head = Tail = node;
            }
            else
            {
                Tail!.Next = node;
                node.Prev = Tail;
                Tail = node;
            }
            Count++;
            return node;
        }

        public void AddAfter(DoublyLinkedListNode<T> node, T value)
        {
            var newNode = new DoublyLinkedListNode<T>(value);
            var next = node.Next;

            node.Next = newNode;
            newNode.Prev = node;
            newNode.Next = next;
            if (next != null) next.Prev = newNode;
            if (Tail == node) Tail = newNode;
            Count++;
        }

        public void Remove(DoublyLinkedListNode<T> node)
        {
            if (node.Prev != null) node.Prev.Next = node.Next;
            else Head = node.Next;

            if (node.Next != null) node.Next.Prev = node.Prev;
            else Tail = node.Prev;

            node.Prev = node.Next = null;
            Count--;
        }

        public void Clear()
        {
            Head = Tail = null;
            Count = 0;
        }

        public IEnumerable<T> AsEnumerable()
        {
            var cur = Head;
            while (cur != null)
            {
                yield return cur.Value;
                cur = cur.Next;
            }
        }
    }
}
